# codsoft_task2
this contains the 2nd task of my time as an intern at codsoft
It is a task of spam SMS detection
